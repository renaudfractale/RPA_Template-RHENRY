﻿Imports Kitware.VTK

Public Class vtkRenderer_rh
    Inherits vtkRenderer
End Class
