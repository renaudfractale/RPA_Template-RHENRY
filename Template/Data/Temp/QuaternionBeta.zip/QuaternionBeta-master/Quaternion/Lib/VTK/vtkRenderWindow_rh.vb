﻿Public Class vtkRenderWindow_rh
    Inherits Kitware.VTK.vtkRenderWindow
End Class
